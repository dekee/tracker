package com.example.taxtracker

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class TaxStatusApp

fun main(args: Array<String>) {
    runApplication<TaxStatusApp>(*args)
}