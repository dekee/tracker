package com.example.taxtracker

import org.springframework.data.jpa.repository.JpaRepository

interface ParcelRepository : JpaRepository<Parcel, String>