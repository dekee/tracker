package com.example.taxtracker

import jakarta.persistence.Entity
import jakarta.persistence.Id

@Entity
data class StatusChange(
    @Id val id: String,
    val parcelId: String,
    val previousStatus: String,
    val currentStatus: String,
    val ownerName: String
)