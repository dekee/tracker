package com.example.taxtracker

import jakarta.persistence.Entity
import jakarta.persistence.Id

@Entity
data class Parcel(
    @Id val id: String,
    val ownerName: String,
    val taxStatus: String,
    val balance: String,
    val parcelNumber: String,
    val address: String,
    val legalDescription: String
)