package com.example.taxtracker

import org.springframework.data.jpa.repository.JpaRepository

interface StatusChangeRepository : JpaRepository<StatusChange, String>